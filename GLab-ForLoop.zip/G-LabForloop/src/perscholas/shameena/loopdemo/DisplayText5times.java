package perscholas.shameena.loopdemo;

 class DisplayText5times {
	public static void main(String[] args) {
		//for loop
		for(int i=0;i<5;i++) {
			System.out.format("Welcome to For loop %d!!!!%n",i+1);
		}
	}
}